<?php
require "../config/conexion.php";
$sql = "SELECT id, candidata, created_at FROM votaciones WHERE 1";
foreach($dbh->query($sql) as $row)
{
    echo "id= ".$row[1]." - candidata=  ".$row['id']."<br>";
}
?>
