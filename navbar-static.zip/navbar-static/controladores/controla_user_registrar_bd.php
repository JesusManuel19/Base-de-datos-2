<?php
require "../config/conexion.php";
$doc = $_POST["doc"];
$can = $_POST["can"];
$sql = "INSERT INTO votaciones(id, candidata, created_at)
VALUES ('".$doc."','".$can."',now())";
if($dbh->query($sql))
{
echo "exito";
}else
{
echo "error";
}
?>
